/*
Name: Mona Jiang and Catharine Zhou
Class: ICS3U7-1
Teacher: Ms. Strelkovska
Assignment: Final Project
Description: Tomato class for Kirby Adventures game, extends star and is a power up
*/

import java.awt.Graphics;

import javax.swing.ImageIcon;

public class Tomato extends Star{
	private int x, y;
	
	public Tomato(int x, int y) {
		super(x, y);
		img = new ImageIcon("tomato.gif");
	}
	
	public boolean isIceCube() {
		return false;
	}
	public void myDraw(Graphics g) {
		g.drawImage(img.getImage(), x+7, y+7, 30, 30, null);
	}
	
	public boolean isTomato() {
		return true;
	}
	
	public boolean isMelon() {
		return false;
	}
}
