import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HighScoreP extends JPanel{
	private JLabel showHighScore;
	private JLabel title;
	private int highScore;
	private Font pixelFont;
	
	public HighScoreP() {
		this.setLayout(new BorderLayout());
		highScore = 0;
		title = new JLabel("High Score");
		showHighScore = new JLabel("High Score: " + highScore + " points");
		
		try {
		    pixelFont = Font.createFont(Font.TRUETYPE_FONT, new File("PixelFont.ttf")).deriveFont(12f);
		    GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
		    g.registerFont(pixelFont);
		} 
		catch (IOException e) {
		    e.printStackTrace();
		} 
		catch(FontFormatException e) {
		    e.printStackTrace();
		}
		
		title.setFont(pixelFont);
		showHighScore.setFont(pixelFont);
		
		this.add(title, BorderLayout.NORTH);
		this.add(showHighScore, BorderLayout.CENTER);
	}
	
	/*public void checkHighScore(int s) {
		if(s > highScore)
			highScore = s;
		System.out.println(highScore);
		showHighScore.setText("High Score: " + highScore + " points");
	}*/
	
}
