/*
Name: Mona Jiang and Catharine Zhou
Class: ICS3U7-1
Teacher: Ms. Strelkovska
Assignment: Final Project
Description: Game panel for Kirby Adventures game
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GamePanel extends JPanel{
//	private StatsP stats;
	private PlayP play;

	public GamePanel() {
		
		//set layout
		//stats= new StatsP();
		play= new PlayP();
		
		this.setLayout(new BorderLayout());
		//this.add(stats, BorderLayout.SOUTH);
		this.add(play, BorderLayout.CENTER);
		setFocusToGameP();
		
	}
	 public void setFocusToGameP() {
		 play.setFocusable(true);
		 play.requestFocus();
	 }
	
}