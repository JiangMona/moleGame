/*
Name: Mona Jiang and Catharine Zhou
Class: ICS3U7-1
Teacher: Ms. Strelkovska
Assignment: Final Project
Description: JFrame for Kirby Adventures game
*/

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.*;
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.Timer;

//kirb
public class MainP extends JFrame implements ActionListener{
	
	static CardLayout cardsL;//can't be private because we will be calling using other classes
	static Container cont;
	private MenuPanel menuP;
	//private GamePanel gameP;
	private PlayP playP;
	//private HighScoreP highScoreP;
	private Timer myTimer;
	
	public MainP(String str) {
		super(str);
		cont = getContentPane();
		cardsL=new CardLayout();
		cont.setLayout(cardsL);
		menuP= new MenuPanel();
		playP= new PlayP();
		//highScoreP = new HighScoreP();

		cont.add("menu", menuP);
		cont.add("game", playP);//next after menu
		//cont.add("high score", highScoreP);
		
		
		this.setContentPane(cont);
		cardsL.show(cont, "menu");
		
		setResizable(false);//cant stretch
		
		myTimer = new Timer(120, this); 
	    myTimer.start();
	}
	
	public static void main(String[] args) {
		MainP javaFrame = new MainP("Kirby Adventures");//my main frame 
		javaFrame.setSize(600, 600);
		javaFrame.setVisible(true);
		javaFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void actionPerformed(ActionEvent e){
		if (e.getSource() == myTimer) {
			menuP.setHighScore(playP.getHighScore());
			menuP.setTimesPlayed(playP.getTimesPlayed());
		}
	}
	

}